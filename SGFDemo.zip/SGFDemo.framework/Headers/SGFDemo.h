//
//  SGFDemo.h
//  SGFDemo
//
//  Created by Sourabh's MacBookPro on 22/04/21.
//

#import <Foundation/Foundation.h>

//! Project version number for SGFDemo.
FOUNDATION_EXPORT double SGFDemoVersionNumber;

//! Project version string for SGFDemo.
FOUNDATION_EXPORT const unsigned char SGFDemoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SGFDemo/PublicHeader.h>


