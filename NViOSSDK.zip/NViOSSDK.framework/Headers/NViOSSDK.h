//
//  NViOSSDK.h
//  NViOSSDK
//
//  Created by Sourabh's MacBookPro on 09/06/21.
//

#import <Foundation/Foundation.h>

//! Project version number for NViOSSDK.
FOUNDATION_EXPORT double NViOSSDKVersionNumber;

//! Project version string for NViOSSDK.
FOUNDATION_EXPORT const unsigned char NViOSSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NViOSSDK/PublicHeader.h>


