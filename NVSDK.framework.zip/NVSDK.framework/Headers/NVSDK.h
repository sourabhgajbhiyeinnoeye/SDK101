//
//  NVSDK.h
//  NVSDK
//
//  Created by Sourabh's MacBookPro on 09/06/21.
//

#import <Foundation/Foundation.h>

//! Project version number for NVSDK.
FOUNDATION_EXPORT double NVSDKVersionNumber;

//! Project version string for NVSDK.
FOUNDATION_EXPORT const unsigned char NVSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NVSDK/PublicHeader.h>


